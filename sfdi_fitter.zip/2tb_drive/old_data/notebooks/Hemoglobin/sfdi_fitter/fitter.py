import lmfit.models as lmmodels
import numpy as np
import tqdm
import time
import eigen_sfdi_fit as cpp_fit

class DiffuseModel:
    """
    Implements model for reflectance in diffuse approximation
    R(k) = Aa'/[(mu_eff/mu_tr + 1)(mu_eff/mu_tr + 3A)]

    where a' = mu_s_prime/(mu_s_prime + mu_a)

    available field
    available methods:

    init_params(self)
    fit(self, k,R)
    """

    def __init__(self, n=1.37):
        """
        n (float) - refractive index
        """

        self.n = n
        self.Reff = self._get_Reff()  # Fresnel effective reflection from the surface
        self.A_c = self._get_A_c()
        self.model = lmmodels.ExpressionModel(
            'C*(ms/(ma+ms))/ ((sqrt(x**2+3*ma*(ma+ms))/(ma+ms)+1)*(sqrt(x**2+3*ma*(ma+ms))/(ma+ms)+C)) ')
        
        
        def fit_function(x,ma,ms,C):
            
            mu_tr = ma + ms
            a_prime = ms/mu_tr
            mu_eff = np.sqrt(3*ma*(ma+ms))
            
            numerator = C*a_prime
            mu_eff_prime = (x**2 + mu_eff**2)**(0.5)
            
            denominator = (mu_eff_prime/mu_tr + 1)*(mu_eff_prime/mu_tr + C)
            
            return numerator/denominator
        
        self.fit_func = fit_function
        
        self.new_model = lmmodels.Model(self.fit_func)
            
        
    def _get_Reff(self):
        Reff = 0.0636 * self.n + 0.668 + (0.71 / self.n) - (1.44 / (self.n ** 2))
        return Reff

    def _get_A_c(self):
        return (1 - self.Reff) / (2 * (1 + self.Reff))

    def init_params(self):
        """initialize standard parameters for model
        assuming spatial frequencies are in mm^-1
        and
        """

        params = self.model.make_params()

        params['ma'].value = 0.2
        params['ma'].vary = True
        #params['ma'].max = 10000
        params['ma'].min = 0
        params['C'].value = 3 * self.A_c
        params['C'].vary = False
        #params['ms'].max = 10000
        params['ms'].vary = True
        params['ms'].value = 3
        params['ms'].min = 0.0

        return params

    def fit(self, k, R, params=None, **kwargs):
        """
        Fit dependency of diffuse reflectance R on spatial frequencies k
        using diffuse model

        :param k (1d np.array): spatial frequencies of signal
        :param R (1d np.array):
        :param params (lmfit.model.Parameters): parameters of Diffuse model self.model.
        Can be properly generated using self.init_params()

        :param kwargs: additional fitting keyword arguments used for fit (see self.model.fit(**kwargs))
        :return: lmfit.model.ModelResult (fit result of diffuse model)
        """
        if params is None:
            params = self.init_params()

        return self.model.fit(data=R, params=params, x=k, **kwargs)

    def evaluate(self, spatial_frequencies, mua=1, mus_prime=10,use_old_model=True):
        """
        evaluates diffuse reflectance for given spatial_frequencies,
        absorption coefficient (mua) and reduced scattering coefficient (mus_prime)

        :param spatial_frequencies (float or np.array of floats): spatial frequencies (2pi/L) in mm^-1
        :param mua (float): absorption coefficient of tissue in mm^-1
        :param mus_prime (float): reduced scattering coefficient of tissue in mm^-1
        :return: (float or np.array of floats) diffuse reflectance for given spatial frequencies, mua and mus_prime
        """

        params = self.init_params()
        params['ma'].value = mua
        params['ms'].value = mus_prime

        if use_old_model:
            return self.model.eval(x=spatial_frequencies, params=params)
        return self.new_model.eval(x=spatial_frequencies,params=params)

def calculate_diffuse_reflectance(spatial_frequencies, mua=1., mus_prime=10., refractive_index=1.37):
    """
    Calculate diffuse reflectance R(k) for given spatial frequencies
    in diffuse model approximation for given absorption coefficients mua,
    reduced scattering coefficient mus_prime and refractive_index

    Note that all parameters should be of the same physical dimension, i.e. mm^-1, or cm^-1

    :param spatial_frequencies: (list or 1d np.array) of spatial frequencies
    :param mua: (float) absorption coefficient, e.g. 1 mm^-1
    :param mus_prime: (float) reduced scattering, e.g. 10 mm^-1
    :param refractive_index: (float) refractive index of tissue (dimensionless)

    :return: (1d np.array) values of diffuse reflectance for given spatial_frequencies
    """
    model = DiffuseModel(n=refractive_index)
    return model.evaluate(spatial_frequencies, mua=mua, mus_prime=mus_prime)

def get_reflectance_stack(freqs_test, mac_test, freqs_reference, mac_reference, ref_mua=1.,
                          ref_mus_prime=10., refractive_index=1.37):
    """
    Calculate reflectance stack based on alternating component of transport function (Mac)
    of test sample and reference sample

    R(k,x,y) = R_ref(k)*Mac_test(k,x,y)/Mac_reference(k,x,y)

    :param freqs_test: (1d np.array) spatial frequencies for test object
    :param mac_test: (3d np.array of shape (len(freqs_test),Nx,Ny)) of  Mac values for different pixels of an image of test object
    :param freqs_reference: (1d np.array) spatial frequencies for reference object
    :param mac_reference: (3d np.array of shape (len(freqs_test),Nx,Ny)) of  Mac values for different pixels of an image of test object
    :param ref_mua: absorption coefficient of reference object
    :param ref_mus_prime: reduced scattering coefficient of reference object
    :param refractive_index: refractive index of reference object
    :return: reflectance 3d np.array stack of shape (len(freqs_test),Nx,Ny) of diffuse reflectance values
    """

    mac_reference_for_freqs = {f: mac for f, mac in zip(freqs_reference, mac_reference)}
    reference_diffuse_reflectance = calculate_diffuse_reflectance(freqs_test, mua=ref_mua,
                                                                  mus_prime=ref_mus_prime,
                                                                  refractive_index=refractive_index)

    mac_reference_reshape = np.stack([mac_reference_for_freqs[f] for f in freqs_test])
    return mac_test * reference_diffuse_reflectance.reshape(-1, 1, 1) / mac_reference_reshape


#TODO: implement multithreading with SharedMemory with python
def fit_diffuse_reflectance_stack(frequencies, reflectance_stack, fit_mask, diffuse_model, backend='python', use_tqdm=True):
    """
    Fit diffuse reflectance stack using diffuse model
    R(k,x,y) ~ DiffuseModel(k,mua,mus_prime), i.e. estimate mua,mus_prime for each pixel
    of an reflectance stack image

    :param frequencies: 1d np.array of spatial frequencies
    :param reflectance_stack: (3d np.array) stack of (len(frequencies), Nx,Ny) shape
    :param fit_mask: (2d np.array of dtype=np.bool of shape (Nx,Ny)) which specifies which pixels should be fitted
    :param diffuse_model: fitter.DiffuseModel() instance with specified refractive index
    :param backend: (str) 'python' or 'cpp'

    :return: fit_results (dict of 'mua','mus','chi2') values for every pixel of an image
    """
    if backend == 'python':  # single processor
        fit_results = {k: np.zeros(reflectance_stack.shape[1:]) for k in ['mua', 'mus', 'chi2','time']}

        x_iterator = tqdm.tqdm(range(reflectance_stack.shape[1])) if use_tqdm else range(reflectance_stack.shape[1])

        for x in x_iterator:
            for y in range(reflectance_stack.shape[2]):
                if fit_mask[x, y]:
                    start_time = time.time()
                    fit_res = diffuse_model.fit(k=frequencies, R=reflectance_stack[:, x, y])
                    fit_results['mua'][x, y] = fit_res.best_values['ma']
                    fit_results['mus'][x, y] = fit_res.best_values['ms']
                    fit_results['chi2'][x, y] = fit_res.chisqr
                    fit_results['time'][x,y] = time.time() - start_time

        return fit_results

    elif backend == 'cpp':
        binned = np.swapaxes(np.swapaxes(reflectance_stack,0,1),1,2)
        guesses = np.zeros((binned.shape[0], binned.shape[1], 4))

        mu_a = 0.2
        mu_s = 2.
        guesses[:, :, 0] = mu_a  # bounded_to_internal(a1)
        guesses[:, :, 1] = mu_s  # bounded_to_internal(tau1)
        guesses[:, :, 2] = 0.  # bounded_to_internal(a2)
        guesses[:, :, 3] = 0.  # bounded_to_internal(tau2)

        fit_required = fit_mask.astype(int)
        ind_mins = np.zeros(binned.shape[:2], dtype=np.int)
        ind_maxs = frequencies.shape[0] - 1  # np.abs(ts - ts_upper).argmax()
        ind_maxs *= np.ones_like(ind_mins)

        res = cpp_fit.fit_pixels(frequencies, np.ascontiguousarray(binned), np.ascontiguousarray(guesses),
                                 np.ascontiguousarray(fit_required), np.ascontiguousarray(ind_mins), np.ascontiguousarray(ind_maxs))

        res = res.reshape((list(binned.shape[:2])+[5]))
        fit_results = {k:res[:,:,i] for i,k in enumerate(['mua','mus'])}
        fit_results.update({k:np.zeros(binned.shape[:2]) for k in ['chi2','times']})

        return fit_results
    else:
        raise ValueError("Only 'python' (lmfit) and 'cpp' backends are available!")
