class BottleneckCSP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.models.common.___torch_mangle_181.Conv
  cv2 : __torch__.torch.nn.modules.conv.___torch_mangle_182.Conv2d
  cv3 : __torch__.torch.nn.modules.conv.___torch_mangle_183.Conv2d
  cv4 : __torch__.models.common.___torch_mangle_186.Conv
  bn : __torch__.torch.nn.modules.batchnorm.___torch_mangle_187.BatchNorm2d
  act : __torch__.torch.nn.modules.activation.___torch_mangle_188.SiLU
  m : __torch__.torch.nn.modules.container.___torch_mangle_196.Sequential
  def forward(self: __torch__.models.common.___torch_mangle_197.BottleneckCSP,
    argument_1: Tensor) -> Tensor:
    cv4 = self.cv4
    act = self.act
    bn = self.bn
    cv2 = self.cv2
    cv3 = self.cv3
    m = self.m
    m0 = self.m
    _0 = getattr(m0, "0")
    cv20 = _0.cv2
    act0 = cv20.act
    cv1 = self.cv1
    _1 = (m).forward((cv1).forward(act0, argument_1, ), )
    _2 = [(cv3).forward(_1, ), (cv2).forward(argument_1, )]
    input = torch.cat(_2, 1)
    _3 = (act).forward((bn).forward(input, ), )
    return (cv4).forward(act0, _3, )
